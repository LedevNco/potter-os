<h1>Bienvenue sur la configuration de l'app météo</h1>
