<script>
    let clicks = 0;
</script>

<button on:click={() => clicks++}>{clicks}</button>